/*
 * Tim.h
 *
 *  Created on: Feb 18, 2021
 *      Author: 40011145
 */

#ifndef TIM_H_
#define TIM_H_
#include "Ifx_Types.h"
#include "Gtm/Tim/In/IfxGtm_Tim_In.h"


#define ISR_PRIORITY_TIMDEMO  7 /* Add interrupt priority for TIM DEMO app */
#define ISR_PRIORITY_TIMDEMO1 9 /* Add interrupt priority for TIM DEMO app */
#define ISR_PROVIDER_TIMDEMO   IfxSrc_Tos_cpu0 /* CPU0 services TIM channel interrupt */
#define MAX_TIM_CHANNEL         6u
#define VAC1_PH_DT_IX         0u
#define VAC2_PH_DT_IX         1u


#define RESET                   0u


#define VAC1_PH_DT          &IfxGtm_TIM0_5_P10_8_IN
#define VAC2_PH_DT          &IfxGtm_TIM0_6_P10_4_IN
#define SNS_FAN1IN          &IfxGtm_TIM0_1_P10_1_IN
#define SNS_FAN2IN          &IfxGtm_TIM0_2_P02_9_IN//2.9
#define SNS_FAN3IN          &IfxGtm_TIM0_7_P23_4_IN//23.4
#define SNS_FAN4IN          &IfxGtm_TIM0_4_P10_0_IN
/******************************************************************************/

/******************************************************************************/
/*--------------------------------Enumerations--------------------------------*/
/******************************************************************************/

/******************************************************************************/
/*-----------------------------Data Structures--------------------------------*/
/******************************************************************************/
typedef struct timchannelconfig{
       uint8 TimModule;
       uint8 TimChannel;
       uint8 isrProvider;
       uint8 isrPriority;
       IfxGtm_Tim_TinMap* PinDetails;
}timchannelconfig;
typedef struct TimPwmDemo_Info_Tag
{
    /* TIM parameters */
    uint8 TimModule;        /* Tim Module used for measurement */
    uint8 TimChannel;       /* Tim Channel used for measurement */
    float32 CaptureFrequency; /* Capture Frequency of Tim Channel */
    float32 duty_percent;   /* Duty Cycle in percentage */
    float32 frequency_hz;   /* Frequency of input PWM in Hz */
    boolean dataCoherent;   /* TRUE: data is coherent. FALSE: data is not coherent */

    /* TOM parameters */
    uint8 TomModule;    /* TOM module used for PWM generation */
    uint8 TomChannel;   /* Tom Channel used for PWM generation */
    float32 PwmFrequency;   /* Frequency of PWM generated */
    float32 pwmduty_percent;    /* duty cycle in percentage */
    uint32 pwmperiod_counts;    /* period in counts */
    uint32 pwmduty_counts;      /* duty in counts */
    float32 tomChannelFreq; /* TOM channel frequency */

    /* counter for ISR Hits */
    uint32 isrHitCount;     /* ISR hit counts */

} TimPwmDemo_Info_T;
extern volatile uint32 PhaseCompleted;
/******************************************************************************/
/*------------------------------Global variables------------------------------*/
/******************************************************************************/
extern TimPwmDemo_Info_T TimPwm_Info[MAX_TIM_CHANNEL];
extern IfxGtm_Tim_In TimPwm_Handler[MAX_TIM_CHANNEL];    /* Handler for TIM config */

extern void TimPwm_Init( timchannelconfig TimChannel, uint8 ucIX );


extern void TomPwmInit (void);
extern void TomPwmStart (void);




#endif /* TIM_H_ */
