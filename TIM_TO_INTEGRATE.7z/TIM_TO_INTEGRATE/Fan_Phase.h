/*
 * Fan_Phase.h
 *
 *  Created on: Feb 18, 2021
 *      Author: 40011145
 */

#ifndef FAN_PHASE_H_
#define FAN_PHASE_H_



extern void Fan_Ac_Fault_Init(void);

extern void measure_PWM(void);

#endif /* FAN_PHASE_H_ */
