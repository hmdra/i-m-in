/**
 *\Module Name  : GPT_Timer
 *\Module ID    : E-13075-01-01_MADK_Unit_GPT_Timer_01
 *\Purpose of module    : This module will used to configure the timers
 *\Authors      : Mohamed Rahmathulla
 *\Date Written : 23 Sep 2020
 *\Modification History:
 *\             >> Revision :1.0
 *\             >> Purpose of modification: Ready for Review
 *\             >> Modified date: 23 Sep 2020
 *\             >> Modified by: Mohamed Rahmathulla
 */
 /******************************************************************************/
 /******************************************************************************/
/*----------------------------------Includes----------------------------------*/
/******************************************************************************/
#include "Ifx_Types.h"
#include "IfxGpt12.h"
#include "IfxPort.h"
#include "GPT_Timer.h"
#include "Bsp.h"
/******************************************************************************/
/*------------------------------Global variables------------------------------*/
/******************************************************************************/
volatile uint32 SignalFlag = 0;
/******************************************************************************/
/*-------------------------Function Prototypes--------------------------------*/
/******************************************************************************/
IFX_INTERRUPT(Timer150usIntr, 0, GPT_100uS_Priority);
/******************************************************************************/
/*------------------------Private Variables/Constants-------------------------*/
/******************************************************************************/

/******************************************************************************/
/*-------------------------Function Implementations---------------------------*/
/******************************************************************************/
/******************************************************************************/
/*-----------------------------Function Header--------------------------------*/
/******************************************************************************/
/******************************************************************************/
/******************************************************************************/
/*
Function name           :Timer100usIntr
DLD ID                  :E-13075-01-01_MADK_Func_GPT_Timer_01
Purpose of the module   :This function is ISR for 100us timer.
Author/s                :Mohamed Rahmathulla
Date written            :23 Sep 2020
Global Variables Referred       :SignalFlag
Global Variables Modified       :SignalFlag
Functions called                :IfxGpt12_T3_setTimerValue
Arguments                       :void
Return Values                   :none
*/
/*****************************************************************************/
void Timer150usIntr(void)
{
    static uint16 Count  = 0;
    Count++;SignalFlag++;
//    IfxPort_togglePin(LED);
    if(Count >= 1500)                              //1ms count
    {
      Count = 0;
//      IfxPort_togglePin(LED);
    }
    IfxGpt12_T3_setTimerValue(&MODULE_GPT120, RELOAD_150us);                                      /* Set T2 reload value to acheive 100us in Timer-3  */
}
/******************************************************************************/
/*
Function name           :Timer20msIntr
DLD ID                  :E-13075-01-01_MADK_Func_GPT_Timer_02
Purpose of the module   :This function is ISR for 20ms timer.
Author/s                :Mohamed Rahmathulla
Date written            :23 Sep 2020
Global Variables Referred       :none
Global Variables Modified       :none
Functions called                :IfxPort_togglePin
Arguments                       :void
Return Values                   :none
*/
/*****************************************************************************/
IFX_INTERRUPT(Timer20msIntr, 0, GPT_20ms_Priority);

void Timer20msIntr(void)
{
//    IfxPort_togglePin(Phase3_Led);
    static uint16 Count  = 0;
    Count++;
//    AddTask_Core0(CanHearbeatmessage, HEART_BEAT_MESSAGE_PRIORITY);
//    AddTask_Core0(Framecantransmit, FRAME_CAN_TRANSMIT_PRIORITY);
    if(Count >= 5)                      //100ms count
    {
      Count = 0;
//      IfxPort_togglePin(LED_1);
    }
//    IfxPort_togglePin(LED_1);
}
/******************************************************************************/
/*
Function name           :Timer20msIntr
DLD ID                  :E-13075-01-01_MADK_Func_GPT_Timer_02
Purpose of the module   :This function is ISR for 20ms timer.
Author/s                :Mohamed Rahmathulla
Date written            :23 Sep 2020
Global Variables Referred       :none
Global Variables Modified       :none
Functions called                :IfxPort_togglePin
Arguments                       :void
Return Values                   :none
*/
/*****************************************************************************/
IFX_INTERRUPT(Timer100usIntr, 0, GPT_Phase3_timer);

void Timer100usIntr(void)
{
//    IfxPort_togglePin(Phase3_Led);
    if(Check_Flag)
    {
        Phase_3_Count++;
        if(Phase_3_Count >= PhaseTimeDifference)
        {
            Check_Flag = 0u;
            Phase_3_Count = 0u;
            PhaseTimeDifference = 0;
            //third phase zero cross detection
            IfxPort_togglePin(Phase3_Led);
//            wait(10000);
//            IfxPort_setPinLow(LED_1);
        }
    }
    IfxGpt12_T2_setTimerValue(&MODULE_GPT120, RELOAD_100us);
}
/******************************************************************************/
/*
Function name           :Init_GptTimer
DLD ID                  :E-13075-01-01_MADK_Func_GPT_Timer_03
Purpose of the module   :This function is used to initiate the GPT timer.
Author/s                :Mohamed Rahmathulla
Date written            :23 Sep 2020
Global Variables Referred       :none
Global Variables Modified       :none
Functions called                :IfxGpt12_enableModule,
                                 IfxGpt12_setGpt1BlockPrescaler
                                 IfxGpt12_T3_setMode
                                 IfxGpt12_T4_setMode
                                 IfxGpt12_T3_setTimerPrescaler
                                 IfxGpt12_T4_setTimerPrescaler
                                 IfxGpt12_T3_setTimerValue
                                 IfxGpt12_T3_getSrc
                                 IfxSrc_init
                                 IfxSrc_enable
                                 IfxGpt12_T3_run
                                 IfxGpt12_T4_run
                                 IfxPort_setPinModeOutput
Arguments                       :void
Return Values                   :none
*/
/*****************************************************************************/
void Init_GptTimer(void)
{
        /* Initialize the GPT12 module */
       IfxGpt12_enableModule(&MODULE_GPT120);                                                        /* Enable the GPT12 module      */
       IfxGpt12_setGpt1BlockPrescaler(&MODULE_GPT120, IfxGpt12_Gpt1BlockPrescaler_4);               /* Set GPT1 block prescaler     */

       /* Initialize the Timer T3 */
       IfxGpt12_T3_setMode(&MODULE_GPT120, IfxGpt12_Mode_timer);                                   /* Set T3 to timer mode for 100us */
       IfxGpt12_T4_setMode(&MODULE_GPT120, IfxGpt12_Mode_timer);                                   /* Set T4 to timer mode for 20ms */
       IfxGpt12_T2_setMode(&MODULE_GPT120, IfxGpt12_Mode_timer);                                   /* Set T2 to timer mode for 1ms */
       IfxGpt12_T3_setTimerPrescaler(&MODULE_GPT120, IfxGpt12_TimerInputPrescaler_1);              /* Set T3 input prescaler       */
       IfxGpt12_T4_setTimerPrescaler(&MODULE_GPT120, IfxGpt12_TimerInputPrescaler_8);              /* Set T4 input prescaler      */
       IfxGpt12_T2_setTimerPrescaler(&MODULE_GPT120, IfxGpt12_TimerInputPrescaler_1);              /* Set T4 input prescaler      */
       IfxGpt12_T3_setTimerValue(&MODULE_GPT120, RELOAD_150us);                                      /* Set T2 reload value to acheive 100us in Timer-3  */
       IfxGpt12_T2_setTimerValue(&MODULE_GPT120, RELOAD_100us);                                      /* Set T2 reload value to acheive 100us in Timer-3  */
       /* Initialize the interrupt */
       volatile Ifx_SRC_SRCR *src = IfxGpt12_T3_getSrc(&MODULE_GPT120);                             /* Get the interrupt address    */
       IfxSrc_init(src, IfxSrc_Tos_cpu0, GPT_100uS_Priority);                                        /* Initialize service request  */
       IfxSrc_enable(src);

       src = IfxGpt12_T4_getSrc(&MODULE_GPT120);                                                     /* Get the interrupt address     */
       IfxSrc_init(src, IfxSrc_Tos_cpu0, GPT_20ms_Priority);                                          /* Initialize service request   */
       IfxSrc_enable(src);                                                                               /* Enable GPT12 interrupt    */

       src = IfxGpt12_T2_getSrc(&MODULE_GPT120);                                                     /* Get the interrupt address     */
       IfxSrc_init(src, IfxSrc_Tos_cpu0, GPT_Phase3_timer);                                          /* Initialize service request   */
       IfxSrc_enable(src);                                                                               /* Enable GPT12 interrupt    */

       IfxGpt12_T3_run(&MODULE_GPT120, IfxGpt12_TimerRun_start);                                           /* Start the timer         */
       IfxGpt12_T4_run(&MODULE_GPT120, IfxGpt12_TimerRun_start);                                              /* Start the timer     */
       IfxGpt12_T2_run(&MODULE_GPT120, IfxGpt12_TimerRun_start);
       /* Initialize the LED */
       IfxPort_setPinModeOutput(LED, IfxPort_OutputMode_pushPull, IfxPort_OutputIdx_general);
       IfxPort_setPinModeOutput(LED_1, IfxPort_OutputMode_pushPull, IfxPort_OutputIdx_general);
       IfxPort_setPinModeOutput(Phase3_Led, IfxPort_OutputMode_pushPull, IfxPort_OutputIdx_general);
}
/*****************************************************************************/
