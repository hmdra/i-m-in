/*
 * Tim.c
 *
 *  Created on: Feb 18, 2021
 *      Author: 40011145
 */


#include "Gtm/Std/IfxGtm.h"
#include "Gtm/Tom/Pwm/IfxGtm_Tom_Pwm.h"
#include "Cpu/Std/IfxCpu.h"
#include "Cpu/Irq/IfxCpu_Irq.h"
#include "Tim.h"
#include "Bsp.h"
#include "GPT_Timer.h"
#include "IfxPort.h"
//#include "IfxCpu.h"
//#include "Ifx_DateTime.h"
volatile uint32 Check_Flag = 0,Phase_3_Count = 0,PhaseTimeDifference = 0;
/*-----------------------------------Macros-----------------------------------*/
/******************************************************************************/
#define TOM_PWM_OUTPUT_FREQUECY_HZ (100000) /* output frequency is 100KHz */
#define TOM_PWM_OUTPUT_DUTY_PERCENT (50)    /* output duty cycle is 50 % */

uint32 Tim1Time = 0;
uint32 Tim2Time = 0;

IfxGtm_Tom_Pwm_Driver TomPwm_Handler;   /* Handler for TOM PWM */

IfxGtm_Tom_Pwm_Config TomPwm_Config;    /* Config structure for TOM */
//IfxGtm_Tim_In TimPwm_Handler[MAX_TIM_CHANNEL];    /* Handler for TIM config */
IfxGtm_Tim_In_Config TimPwm_Config; /* Config Structure for TIM */
TimPwmDemo_Info_T TimPwm_Info[MAX_TIM_CHANNEL]; /**< \brief Demo information */




IFX_INTERRUPT(VAC1_PH_DT_ISR, 0, ISR_PRIORITY_TIMDEMO);
IFX_INTERRUPT(VAC2_PH_DT_ISR, 0, ISR_PRIORITY_TIMDEMO1);

void VAC1_PH_DT_ISR(void)
{
    IfxCpu_enableInterrupts();
//    printf("ISR HIT");
    Tim1Time = (sint32)(now() / TimeConst_100us);
    TimPwm_Info[0].isrHitCount ++;
    IfxPort_togglePin(LED_1);
//    IfxGtm_Tim_In_onIsr(&TimPwm_Handler[VAC1_PH_DT_IX]);
}

void VAC2_PH_DT_ISR(void)
{
    IfxCpu_enableInterrupts();
//    printf("ISR HIT");
    TimPwm_Info[1].isrHitCount ++;
    Tim2Time = (sint32)(now() / TimeConst_100us);
    PhaseCompleted = 1;
    Check_Flag = 1;
    PhaseTimeDifference = Tim2Time - Tim1Time;
    IfxPort_togglePin(LED);
    /*
     * enable the third timer using the difference between timer1 and timer 2
     */
//    IfxGtm_Tim_In_onIsr(&TimPwm_Handler[VAC2_PH_DT_IX]);
}





/* TIM measurement initialization */
IFX_EXTERN void TimPwm_Init( timchannelconfig TimChannel, uint8 ucIX )
{
//    printf("TIM init called\n");


    /* enable interrupts */
    IfxCpu_enableInterrupts();

    /* Initialize the Config Structure */
    IfxGtm_Tim_In_Config *config = &TimPwm_Config;
    IfxGtm_Tim_In_initConfig(config, &MODULE_GTM);

    /* Configure the Channel used */
    config->gtm                          = &MODULE_GTM;
    config->timIndex                     = TimChannel.TimModule;//IfxGtm_Tim_0;
    config->channelIndex                 = TimChannel.TimChannel;//IfxGtm_Tim_Ch_0;

    if(ucIX < 2u)
    {
        /* Configure the Capture Configurations */
        config->capture.irqOnNewVal          = TRUE; /* give me an interrupt on NEWVAL */
        config->capture.irqOnCntOverflow     = FALSE;
        config->capture.irqOnEcntOverflow    = FALSE;
        config->capture.irqOnDatalost        = FALSE;
        config->timeout.irqOnTimeout         = FALSE;
        /* Configure Interrupt parameters */
        config->irqMode                      = IfxGtm_IrqMode_pulseNotify;
        config->isrProvider                  = TimChannel.isrProvider;//ISR_PROVIDER_TIMDEMO;
        config->isrPriority                  = TimChannel.isrPriority;//ISR_PRIORITY_TIMDEMO;
    }


    /* Enable the CMU clock for TIM */
    MODULE_GTM.CMU.CLK_EN.B.EN_CLK0 = 0x2;     /* enable the CMU clock 0 now */


    config->capture.clock                = IfxGtm_Cmu_Clk_0;
    config->capture.mode                 = Ifx_Pwm_Mode_leftAligned;

    /* Configure Timeout */

    config->timeout.clock                = IfxGtm_Cmu_Clk_0;
    config->timeout.timeout              = 0.0;

    /* Configure the Input */
    config->filter.input                 = IfxGtm_Tim_In_Input_currentChannel;
    config->filter.inputPin              = TimChannel.PinDetails;//&IfxGtm_TIM0_0_P02_0_IN; /* Use Port 02 channel 0 */
    config->filter.inputPinMode          = IfxPort_InputMode_noPullDevice;

    /* Configure Filter parameters */
    config->filter.risingEdgeMode        = IfxGtm_Tim_In_ConfigFilterMode_none;
    config->filter.fallingEdgeMode       = IfxGtm_Tim_In_ConfigFilterMode_none;
    config->filter.risingEdgeFilterTime  = 0;
    config->filter.fallingEdgeFilterTime = 0;
    config->filter.clock                 = IfxGtm_Cmu_Tim_Filter_Clk_0;

    /* Initialize the TIM Channel Now */
    IfxGtm_Tim_In_init(&TimPwm_Handler[ucIX], config);

    /* Read the TIM configuration information here */
    TimPwm_Info[ucIX].TimModule = (uint8)config->timIndex;
    TimPwm_Info[ucIX].TimChannel = (uint8)config->channelIndex;
    TimPwm_Info[ucIX].CaptureFrequency = TimPwm_Handler[ucIX].captureClockFrequency;

//    printf("TIM capture frequency = %d", (int)TimPwm_Info[ucIX].CaptureFrequency);
}


/* Initialize the TOM PWM module for output */
extern void TomPwmInit (void)
{
    IfxGtm_Tom_Pwm_Config *config = &TomPwm_Config;

    IfxGtm_Tom_Pwm_initConfig(config, &MODULE_GTM); /* initialize the config */

    /* Configure the TOM channel */
    config->tom                      = IfxGtm_Tom_0;
    config->tomChannel               = IfxGtm_Tom_Ch_0;

    /* Configure the clock */
    config->clock                    = IfxGtm_Tom_Ch_ClkSrc_cmuFxclk0; /* Use FX clock 0 (divide by 1) */

    /* Configure the period and dutycycle counts */

    MODULE_GTM.CMU.CLK_EN.B.EN_FXCLK = 0x2;     /* enable the FX clock now */
    TimPwm_Info[0].tomChannelFreq = IfxGtm_Cmu_getFxClkFrequency(&MODULE_GTM, (IfxGtm_Cmu_Fxclk)config->clock, FALSE);

//    printf("TOM channel frequency = %d",(int)TimPwm_Info[0].tomChannelFreq);

    config->period                   = (uint32)(TimPwm_Info[0].tomChannelFreq / TOM_PWM_OUTPUT_FREQUECY_HZ);
    config->dutyCycle                = (uint32)( (TOM_PWM_OUTPUT_DUTY_PERCENT * config->period)/ 100 );

    /* output parameters */
    config->signalLevel              = Ifx_ActiveState_high;
    config->oneShotModeEnabled       = FALSE;
    config->synchronousUpdateEnabled = TRUE;
    config->immediateStartEnabled    = FALSE;

    /* Interrupt parameters */
    config->interrupt.ccu0Enabled    = FALSE;
    config->interrupt.ccu1Enabled    = FALSE;
    config->interrupt.mode           = IfxGtm_IrqMode_pulseNotify;
    config->interrupt.isrProvider    = ISR_PROVIDER_TIMDEMO;
    config->interrupt.isrPriority    = 0;

    /* Output pin parameters */
    config->pin.outputPin            = &IfxGtm_TOM0_0_TOUT18_P00_9_OUT;
    config->pin.outputMode           = IfxPort_OutputMode_pushPull;
    config->pin.padDriver            = IfxPort_PadDriver_cmosAutomotiveSpeed1;

    /* Initialize the TOM channel now */
    IfxGtm_Tom_Pwm_init(&TomPwm_Handler, config);

    /* Read into the info variable now */
    TimPwm_Info[0].PwmFrequency = TOM_PWM_OUTPUT_FREQUECY_HZ;
    TimPwm_Info[0].pwmduty_percent = TOM_PWM_OUTPUT_DUTY_PERCENT;
    TimPwm_Info[0].TomModule = config->tom;
    TimPwm_Info[0].TomChannel = config->tomChannel;
    TimPwm_Info[0].pwmduty_counts = config->dutyCycle;
    TimPwm_Info[0].pwmperiod_counts = config->period;

//    printf("TOM PWM duty counts = %d",(int)TimPwm_Info[0].pwmduty_counts );
//    printf("TOM PWM period counts = %d",(int)TimPwm_Info[0].pwmperiod_counts );

}


extern void TomPwmStart (void)
{
    IfxGtm_Tom_Pwm_start(&TomPwm_Handler, TRUE);
}

