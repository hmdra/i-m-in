/*
 * Fan_Phase.c
 *
 *  Created on: Feb 18, 2021
 *      Author: 40011145
 */


#include "Tim.h"
#include "Gtm/Std/IfxGtm.h"


IfxGtm_Tim_In TimPwm_Handler[MAX_TIM_CHANNEL];    /* Handler for TIM config */

float32 g_measuredPwmDutyCycle[6] = {0.0};                   /* Global variable for duty cycle of generated PWM signal   */
float32 g_measuredPwmFreq_Hz[6] = {0.0};                     /* Global variable for frequency calculation of PWM signal  */
float32 g_measuredPwmPeriod[6] = {0.0};                      /* Global variable for period calculation of PWM signal     */
boolean g_dataCoherent = FALSE;

timchannelconfig timchannelData[MAX_TIM_CHANNEL] = {
                                                        {IfxGtm_Tim_0,IfxGtm_Tim_Ch_5, ISR_PROVIDER_TIMDEMO, ISR_PRIORITY_TIMDEMO,   VAC1_PH_DT},
                                                        {IfxGtm_Tim_0,IfxGtm_Tim_Ch_6, ISR_PROVIDER_TIMDEMO, ISR_PRIORITY_TIMDEMO1,  VAC2_PH_DT},
                                                        {IfxGtm_Tim_0,IfxGtm_Tim_Ch_1, RESET, RESET,  SNS_FAN1IN},
                                                        {IfxGtm_Tim_0,IfxGtm_Tim_Ch_2, RESET, RESET,  SNS_FAN2IN},
                                                        {IfxGtm_Tim_0,IfxGtm_Tim_Ch_7, RESET, RESET,  SNS_FAN3IN},
                                                        {IfxGtm_Tim_0,IfxGtm_Tim_Ch_4, RESET, RESET,  SNS_FAN4IN}
                                                    };

extern void Fan_Ac_Fault_Init(void)
{

    /* enable GTM before anything else */
     IfxGtm_enable(&MODULE_GTM);

    /* Initialize the TOM for output */
    TomPwmInit();

    /* Initialize the TIM  for measurement */
    for(uint8 ucLoopCounter=0; ucLoopCounter<6; ucLoopCounter++)
        TimPwm_Init(timchannelData[ucLoopCounter],ucLoopCounter);

    /* Start the PWM drive by TOM */
    TomPwmStart();

    //p10.4 -vac2
    //p10.8 - vac1


}

extern void measure_PWM(void)
{
    for(int i = 2; i<6;i++)
    {
        IfxGtm_Tim_In_update(&TimPwm_Handler[i]);                                         /* Update the measured data         */
        g_measuredPwmPeriod[i] = IfxGtm_Tim_In_getPeriodSecond(&TimPwm_Handler[i]);          /* Get the period of the PWM signal */
        g_measuredPwmFreq_Hz[i] = 1 / g_measuredPwmPeriod[i];                             /* Calculate the frequency          */
        g_measuredPwmDutyCycle[i] = IfxGtm_Tim_In_getDutyPercent(&TimPwm_Handler[i], &g_dataCoherent); /* Get the duty cycle     */
    }

}

