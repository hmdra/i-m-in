/**
 *\Module Name  : GPT_Timer
 *\Module ID    : E-13075-01-01_MADK_Unit_GPT_Timer_01
 *\Purpose of module    : This module will used to configure the timers
 *\Authors      : Mohamed Rahmathulla
 *\Date Written : 23 Sep 2020
 *\Modification History:
 *\             >> Revision :1.0
 *\             >> Purpose of modification: Ready for Review
 *\             >> Modified date: 23 Sep 2020
 *\             >> Modified by: Mohamed Rahmathulla
 */
 /******************************************************************************/
#ifndef SERVICELAYER_GPT_TIMER_H_
#define SERVICELAYER_GPT_TIMER_H_
/******************************************************************************/
/*-----------------------------------Macros-----------------------------------*/
/******************************************************************************/
#define GPT_100uS_Priority          10u
#define GPT_20ms_Priority           12u
#define GPT_Phase3_timer            11u

#define RELOAD_100us                63036u
#define RELOAD_150us                61785u
#define LED                         &MODULE_P13, 0          /* LED which toggles in the Interrupt Service Routine   */
#define LED_1                       &MODULE_P13, 1          /* LED which toggles in the Interrupt Service Routine   */
#define Phase3_Led                  &MODULE_P13, 2          /* LED which toggles in the Interrupt Service Routine   */

/******************************************************************************/
/*-------------------------Function Prototypes--------------------------------*/
/******************************************************************************/
extern void Init_GptTimer(void);
extern volatile uint32 SignalFlag,Check_Flag,Phase_3_Count,PhaseTimeDifference;
/******************************************************************************/
#endif /* SERVICELAYER_GPT_TIMER_H_ */
