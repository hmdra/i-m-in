 /*
 *\Module Name  : TIMER
 *\Module ID    : I00214-01-01_SJB_Unit_TIMER_01
 *\Purpose of module    : This module will initialize timer and ISR will occur periodically.
 *\Authors      : Infineon
 *\Date Written : 03Jan2020
 *\Modification History:
 *\             >> Revision :1.0
 *\             >> Purpose of modification: ISR routine modified
 *\             >> Modified date: 18 Dec 2019
 *\             >> Modified by: Narayanan
 *\             >> Revision : 1.2
 *\             >> Purpose of modification: Updated to fix SW IT bugs
 *\             >> Modified date: 21 Jan 2020
 *\             >> Modified by: Narayanan
 */
#ifndef STMDEMO_H
#define STMDEMO_H 1
/******************************************************************************/
/*----------------------------------Includes----------------------------------*/
/******************************************************************************/
#include <Ifx_Types.h>
#include "Bsp.h"
#include "Cpu/Irq/IfxCpu_Irq.h"
#include <Stm/Std/IfxStm.h>
#include <Src/Std/IfxSrc.h>
#include "Cpu/Irq/IfxCpu_Irq.h"

/******************************************************************************/
/*-----------------------------------Macros-----------------------------------*/
/******************************************************************************/
#define ONE_SEC			100000u	/*10us timer*/
#define HUNDREAD_MS		10000u	/*10us timer*/
#define TWO_HUNDREAD_MS	20000u
#define ONE_FORTY_US	14u	/*10us timer*/
#define CONVERTER_TIME	100u	/*30us timer*/
/******************************************************************************/
/*--------------------------------Enumerations--------------------------------*/
/******************************************************************************/
/******************************************************************************/
/*-----------------------------Data Structures--------------------------------*/
/******************************************************************************/

typedef struct
{
    Ifx_STM             *stmSfr;            /**< \brief Pointer to Stm register base */
    IfxStm_CompareConfig stmConfig;         /**< \brief Stm Configuration structure */
    volatile uint32      CanResponseCounter;          /**< \brief LED state variable */
    volatile uint16      m_unCounter;           /**< \brief interrupt counter */
    volatile uint32		 m_ulnTimerDealy;
    volatile uint32      m_ulnHearBeatMessageCounter;
    volatile uint32      m_ulnWatchDogCounter;
    volatile uint32      m_ulnToggleLedTimer;
    volatile uint32      m_ulnConverterTimer;
    volatile uint32      m_ulnAdcTimeOutTimer;
    volatile uint32      m_ulnCANTimeoutTimer;
} App_Stm;
/******************************************************************************/
/*------------------------------Global variables------------------------------*/
/******************************************************************************/
//IFX_EXTERN App_Stm g_Stm;
/******************************************************************************/
/*-------------------------Function Prototypes--------------------------------*/
/******************************************************************************/
IFX_EXTERN uint8 InitSystemTimer(void);
IFX_EXTERN uint16 ReadStmTimeCounter(void);
IFX_EXTERN uint8 EnableConverterTimer(void);
IFX_EXTERN uint8 DisableConverterTimer(void);
IFX_EXTERN void Delay(uint16 delay);
IFX_EXTERN uint16 ReadTimer(void);
extern uint32 ReadTimer1(void);

void UpdateSamplingEventTime(float32 fTime);
#endif
