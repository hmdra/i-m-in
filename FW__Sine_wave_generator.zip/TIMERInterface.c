/*
 *\Module Name  : TIMER
 *\Module ID    : I00214-01-01_SJB_Unit_TIMER_01
 *\Purpose of module    : This module will initialize timer and ISR will occur periodically.
 *\Authors      : Infineon
 *\Date Written : 03Jan2020
 *\Modification History:
 *\             >> Revision : 1.0
 *\             >> Purpose of modification: ISR routine modified
 *\             >> Modified date: 18 Dec 2019
 *\             >> Modified by: Narayanan
 *\
 *\             >> Revision : 1.2
 *\             >> Purpose of modification: Updated to fix SW IT bugs
 *\             >> Modified date: 21 Jan 2020
 *\             >> Modified by: Narayanan
 *\
 *\             >> Revision : 1.3
 *\             >> Purpose of modification: Read current time from other components
 *\             >> Modified date: 24 Jan 2020
 *\             >> Modified by: Narayanan
 */
/******************************************************************************/
/*----------------------------------Includes----------------------------------*/
/******************************************************************************/
#include "TIMERInterface.h"
#include "../SinLut.h"
/******************************************************************************/
/*-----------------------------------Macros-----------------------------------*/
/******************************************************************************/
#define TIME_SCALAR_US		10u
#define ISR_PRIORITY_STM_INT0   5u
#define HUNDREAD_US             100u
/******************************************************************************/
/*--------------------------------Enumerations--------------------------------*/
/******************************************************************************/

/******************************************************************************/
/*-----------------------------Data Structures--------------------------------*/
/******************************************************************************/

/******************************************************************************/
/*------------------------------Global variables------------------------------*/
/******************************************************************************/
/*
 * Variable Name: g_statEnableLhmTimer
 *\Purpose: It will activate LHM time counter.
 *\Functions using this variable:
 *\         1. STM_Int0Handler
 *\         2. EnableLhmTimer
 */
static uint8 g_statConverterTimer=0u;

/*
 * Variable Name: g_stat_Stm
 *\Purpose: It will have the STM configuration registers and time counters.
 *\Functions using this variable:
 *\         1. STM_Int0Handler
 *\         2. IfxStmInit
 *\         3. ReadStmTimeCounter
 *\         4. EnableLhmTimer
 */
static App_Stm g_stat_Stm; /**< \brief Stm global data */
/******************************************************************************/
/*-------------------------Function Prototypes--------------------------------*/
/******************************************************************************/
/******************************************************************************/
/*------------------------Private Variables/Constants-------------------------*/
/******************************************************************************/
static uint32 ulnTimer;
static uint16 unSineSamplingEvent = RESET;
/******************************************************************************/
/*-------------------------Function Implementations---------------------------*/
/******************************************************************************/

/******************************************************************************/
/*------------------------------------ISR-------------------------------------*/
/******************************************************************************/
/*-----------------------------Function Header--------------------------------*/
/******************************************************************************/
/*
Function name           :TimerEvent
DLD ID                  :I-00214-01-01_SJB_Func_ TIMER _04
Purpose of the module   :Interrupt service routine for Timer.
Author/s                :Narayanan
Date written            :25Oct2019
Global Variables Referred       :None
Global Variables Modified       :g_stat_Stm
Functions called                :1) IfxStm_clearCompareFlag
                                 2) IfxStm_increaseCompare
                                 3) IfxCpu_enableInterrupts
                                 4) AddTask
Arguments                       :None
Return Values                   :None
*/
/***************************************************************************/
/******************************************************************************/
IFX_INTERRUPT(TimerEvent, 0, ISR_PRIORITY_STM_INT0);
/************************************************************************/
void TimerEvent(void)
{
    IfxCpu_disableInterrupts();
    IfxStm_clearCompareFlag(g_stat_Stm.stmSfr, g_stat_Stm.stmConfig.comparator);
#ifdef SIMULATION
    IfxStm_increaseCompare(g_stat_Stm.stmSfr, g_stat_Stm.stmConfig.comparator, 1000);
#else
    IfxStm_increaseCompare(g_stat_Stm.stmSfr, g_stat_Stm.stmConfig.comparator, TimeConst_10us);
#endif
    ulnTimer++;
    g_stat_Stm.m_ulnTimerDealy++;
    if(g_stat_Stm.m_ulnTimerDealy >= (unSineSamplingEvent-1))
    {
        g_stat_Stm.m_ulnTimerDealy = RESET;
        UpdateSinInstantVoltage();
        Comparator();
    }
    IfxCpu_enableInterrupts();
}
/*******************************************************************************/

/******************************************************************************/
/*-----------------------------Function Header--------------------------------*/
/******************************************************************************/
/*
Function name           :IfxStmDemo_init
DLD ID                  :I-00214-01-01_SJB_Func_ TIMER _01
Purpose of the module   :To initialize timer module for 1ms
Author/s                :Infineon
Date written            :25Oct2019
Global Variables Referred       :None
Global Variables Modified       :g_stat_Stm
Functions called                :1) IfxCpu_disableInterrupts
                                 2) initTime
                                 3) IfxStm_initCompareConfig
                                 4) IfxStm_initCompare
                                 5) IfxCpu_restoreInterrupts
Arguments                       :None
Return Values                   :None
*/
/***************************************************************************/
extern uint8 InitSystemTimer(void)
{
    /* disable interrupts */
    //boolean bInterruptState = IfxCpu_disableInterrupts();
    boolean bInitializationStatus;

    initTime();
    g_stat_Stm.stmSfr = &MODULE_STM0;
    IfxStm_initCompareConfig(&g_stat_Stm.stmConfig);

    g_stat_Stm.stmConfig.triggerPriority = ISR_PRIORITY_STM_INT0;
    g_stat_Stm.stmConfig.typeOfService   = IfxSrc_Tos_cpu0;
#ifdef SIMULATION
    g_SrcSwInt.stmConfig.ticks      = 1000;
#else
  //  g_stat_Stm.stmConfig.ticks           = TimeConst_1s;
    g_stat_Stm.stmConfig.ticks           = (uint32)TimeConst_10us;
#endif
    bInitializationStatus=IfxStm_initCompare(g_stat_Stm.stmSfr, &g_stat_Stm.stmConfig);
     /* enable interrupts again */
    //IfxCpu_restoreInterrupts(bInterruptState);
    return (uint8)bInitializationStatus;
}
/*******************************************************************************/

/******************************************************************************/
/*-----------------------------Function Header--------------------------------*/
/******************************************************************************/
/*
Function name           :EnableLhmTimer
DLD ID                  :I-00214-01-01_SJB_Func_ TIMER _03
Purpose of the module   :To enable LHM timer
Author/s                :Narayanan
Date written            :25Oct2019
Global Variables Referred       :g_stat_Stm
Global Variables Modified       :None
Functions called                :None
Arguments                       :None
Return Values                   :None
*/
/***************************************************************************/
extern uint8 EnableConverterTimer(void)
{
	g_statConverterTimer = SET;
	return 1u;
}
/*******************************************************************************/

/******************************************************************************/
/*-----------------------------Function Header--------------------------------*/
/******************************************************************************/
/*
Function name           :ResetTimer
DLD ID                  :I-00214-01-01_SJB_Func_ TIMER _04
Purpose of the module   :To reset TimeCounter variable
Author/s                :Narayanan
Date written            :25Oct2019
Global Variables Referred       :g_stat_Stm
Global Variables Modified       :None
Functions called                :None
Arguments                       :None
Return Values                   :None
*/
/***************************************************************************/
extern uint8 DisableConverterTimer(void)
{
	g_statConverterTimer = RESET;
	return 1u;
}
/*******************************************************************************/

/******************************************************************************/
/*-----------------------------Function Header--------------------------------*/
/******************************************************************************/
/*
Function name           :Delay_ms
DLD ID                  :I-00214-01-01_SJB_Func_ TIMER _05
Purpose of the module   :To provide delay in ms
Author/s                :Narayanan
Date written            :15Jan2020
Global Variables Referred       :g_stat_Stm
Global Variables Modified       :g_stat_Stm
Functions called                :None
Arguments                       :None
Return Values                   :None
*/
/***************************************************************************/
extern void Delay(uint16 unDelay)
{
	unDelay = unDelay/TIME_SCALAR_US;	/* To scale from 10us to 1us*/
    g_stat_Stm.m_ulnTimerDealy = RESET;
    while(g_stat_Stm.m_ulnTimerDealy<unDelay);
}
/*******************************************************************************/

/******************************************************************************/
/*-----------------------------Function Header--------------------------------*/
/******************************************************************************/
/*
Function name           :ReadTimer
DLD ID                  :I-00214-01-01_SJB_Func_ TIMER _06
Purpose of the module   :To read current time
Author/s                :Narayanan
Date written            :24/01/2020
Global Variables Referred       :g_stat_Stm
Global Variables Modified       :g_stat_Stm
Functions called                :None
Arguments                       :None
Return Values                   :g_stat_Stm.m_unArcTimer
*/
/***************************************************************************/
extern uint16 ReadTimer(void)
{
	return g_stat_Stm.m_unCounter;
}
extern uint32 ReadTimer1(void)
{
	return ulnTimer;
}
void UpdateSamplingEventTime(float32 fTime)
{
    unSineSamplingEvent = fTime/0.00001;
}
