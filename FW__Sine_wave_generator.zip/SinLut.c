/*
 * SinLut.c
 *
 *  Created on: 10 Nov 2020
 *      Author: Narayanan
 */
#include "Ifx_Types.h"
#include "IfxCpu.h"
#include <math.h>
#include "SinLut.h"

static stSineWaveParameters g_stat_stPhaseA;
static stSineWaveParameters g_stat_stPhaseB;
static stSineWaveParameters g_stat_stPhaseC;

static uint16 g_stat_unCurrentSample;

boolean UpdateSinLut(float32 fSinFreq, float32 fSinAmplitude)
{
    boolean bLutStatus = RESET;
    uint8 ucLoopCounter = FALSE;
    if((fSinFreq<MIN_FREQUENCY)||(fSinFreq>MAX_FREQUENCY)||(fSinAmplitude>MAX_AMPLITUDE))
    {
        bLutStatus = RESET;
    }
    else
    {
        g_stat_stPhaseA.m_fSamplingTime = (1/fSinFreq)/MAX_SAMPLE;  /*Get the Sampling time according to sine frequency*/
        g_stat_stPhaseB.m_fSamplingTime = g_stat_stPhaseA.m_fSamplingTime;  /*Sampling time will be same for all the phase*/
        g_stat_stPhaseC.m_fSamplingTime = g_stat_stPhaseA.m_fSamplingTime;  /*Sampling time will be same for all the phase*/

        g_stat_stPhaseA.m_fPhaseShift  = 0;    /*No Phase Shift*/
        g_stat_stPhaseB.m_fPhaseShift  = 120.0F/(fSinFreq*360.0F);  /*120 degree Phase Shift*/
        g_stat_stPhaseC.m_fPhaseShift  = 240.0F/(fSinFreq*360.0F);  /*240 degree Phase Shift*/

        for(;ucLoopCounter<MAX_SAMPLE;ucLoopCounter++)
        {
            g_stat_stPhaseA.m_fSinLut[ucLoopCounter] = fSinAmplitude*(sin(SIN_CONST*fSinFreq*((g_stat_stPhaseA.m_fSamplingTime*ucLoopCounter)+g_stat_stPhaseA.m_fPhaseShift))); /*Instant voltage computation for PHASE A*/
            g_stat_stPhaseA.m_fSinLut[ucLoopCounter] =  g_stat_stPhaseA.m_fSinLut[ucLoopCounter]+fSinAmplitude;     /*Level shifting for to get only positive value*/

            g_stat_stPhaseB.m_fSinLut[ucLoopCounter] = fSinAmplitude*(sin(SIN_CONST*fSinFreq*((g_stat_stPhaseB.m_fSamplingTime*ucLoopCounter)+g_stat_stPhaseB.m_fPhaseShift))); /*Instant voltage computation for PHASE B*/
            g_stat_stPhaseB.m_fSinLut[ucLoopCounter] = g_stat_stPhaseB.m_fSinLut[ucLoopCounter]+fSinAmplitude;     /*Level shifting for to get only positive value*/

            g_stat_stPhaseC.m_fSinLut[ucLoopCounter] = fSinAmplitude*(sin(SIN_CONST*fSinFreq*((g_stat_stPhaseC.m_fSamplingTime*ucLoopCounter)+g_stat_stPhaseC.m_fPhaseShift))); /*Instant voltage computation for PHASE C*/
            g_stat_stPhaseC.m_fSinLut[ucLoopCounter] =  g_stat_stPhaseC.m_fSinLut[ucLoopCounter]+fSinAmplitude;     /*Level shifting for to get only positive value*/
        }
        g_stat_stPhaseA.m_fSineFrequency = fSinFreq;    /*Updating frequency for future reference*/
        g_stat_stPhaseA.m_fSineAmplitude = fSinAmplitude;   /*Updating amplitude for future reference*/
        bLutStatus = SET;
    }
    UpdateSamplingEventTime(g_stat_stPhaseA.m_fSamplingTime);
    return bLutStatus;
}

void UpdateSinInstantVoltage(void)
{
   if(g_stat_unCurrentSample >= MAX_SAMPLE)
     {
       g_stat_unCurrentSample = RESET;
     }
   g_stat_unCurrentSample++;    /* Increase Array Index of look up table*/
}

float32 GetSineFrequency(void)
{
    return g_stat_stPhaseA.m_fSineFrequency;
}

float32 GetSineAmplitude(void)
{
    return g_stat_stPhaseA.m_fSineAmplitude;
}

void ResetCurrentSample(void)
{
    g_stat_unCurrentSample = RESET;
}

float32 GetInstantVoltage(uint8 ucPhase)
{
    float32 fFrequency = 0.0F;
    switch (ucPhase)
    {
        case 0:
            fFrequency = g_stat_stPhaseA.m_fSinLut[g_stat_unCurrentSample]; /*read phase A instant voltage*/
            break;

        case 1:
            fFrequency = g_stat_stPhaseB.m_fSinLut[g_stat_unCurrentSample]; /*read phase B instant voltage*/
            break;

        case 2:
            fFrequency = g_stat_stPhaseC.m_fSinLut[g_stat_unCurrentSample]; /*read phase C instant voltage*/
            break;
        default:
            break;
    }
    return fFrequency;
}
