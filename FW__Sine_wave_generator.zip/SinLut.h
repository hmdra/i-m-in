/*
 * SinLut.h
 *
 *  Created on: 10 Nov 2020
 *      Author: Narayanan
 */

#ifndef SINLUT_H_
#define SINLUT_H_

#define MAX_SAMPLE      200u
#define SIN_CONST       6.28F
#define MAX_FREQUENCY   50.0F
#define MIN_FREQUENCY   10.0F
#define MAX_AMPLITUDE   30000.0F

boolean UpdateSinLut(float32 fSinFreq, float32 fSinAmplitude);
void UpdateSinInstantVoltage(void);
float32 GetSineFrequency(void);
float32 GetSineAmplitude(void);
void ResetCurrentSample(void);
float32 GetInstantVoltage(uint8 ucPhase);

void Comparator(void);

typedef struct
{
        float32 m_fSinLut[MAX_SAMPLE];
        float32 m_fSineFrequency;
        float32 m_fSineAmplitude;
        float32 m_fSamplingTime;
        float32 m_fPhaseShift;
}stSineWaveParameters;
#endif /* SINLUT_H_ */
